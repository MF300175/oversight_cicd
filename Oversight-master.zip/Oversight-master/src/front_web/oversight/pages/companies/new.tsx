import { Box, Typography, styled } from "@mui/material";
import React from "react";
import CompanyForm from "../../components/CompanyForm";
import LoginPage from "../../components/LoginPage";

const index = () => {
  return <CompanyForm />;
};

export default index;
